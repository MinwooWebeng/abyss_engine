﻿namespace AbyssCLI.AmlDepr.API;

public class Time
{
}
