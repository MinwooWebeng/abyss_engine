﻿namespace AbyssCLI.AmlDepr.API;

public static class Player
{
}
